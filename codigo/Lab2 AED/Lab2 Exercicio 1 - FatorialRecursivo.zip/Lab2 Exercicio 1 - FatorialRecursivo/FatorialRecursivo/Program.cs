﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FatorialRecursivo
{
    class Program
    {
        static void Main(string[] args)
        {
            int Fat = 1;
            int n;
            Console.Write(" Calcular o fatorial do numero: ");
            n = int.Parse(Console.ReadLine());

            Fat = Fatorial(n);

            Console.WriteLine($" O Calculo Fatorial do Numero {n} é {Fat}.");

            Console.ReadKey();
        }
        static int Fatorial(int x)
        {
            if (x == 0)
                return 1;
            else
                return x * Fatorial(x - 1);
        }
    }
}