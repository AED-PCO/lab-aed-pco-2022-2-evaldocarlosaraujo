﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PotenciacaoRecursiva
{
    class Program
    {
        static int PotRecursiva(int num, int n)
        {
            if (n == 1)
            {
                return num;
            }
            return num * PotRecursiva(num, n - 1);
        }
        static void Main(string[] args)
        {
            int resultado;
            resultado = PotRecursiva(5, 3);

            Console.WriteLine("Passados dois numeros por parametros 5 e 3: ");
            Console.WriteLine($"O resultado do potencia é {resultado} ");
            Console.ReadKey();
        }
    }
}
