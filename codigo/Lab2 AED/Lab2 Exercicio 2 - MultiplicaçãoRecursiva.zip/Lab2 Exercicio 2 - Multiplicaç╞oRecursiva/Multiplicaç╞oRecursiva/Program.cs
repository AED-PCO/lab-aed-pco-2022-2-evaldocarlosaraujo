﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiplicaçãoRecursiva
{
    class Program
    {
        public static int multiplicacao(int vezes, int valor)
        {
            if (vezes == 0 || valor == 0)
            {
                return (0);
            }
            else if (vezes == 1)
            {
                return (valor);
            }
            else
            { 
               return valor + multiplicacao(vezes -1, valor);
            }
        }
        static void Main(string[] args)
        {
            int Resultado;

            Resultado = multiplicacao(5, 3);

            Console.WriteLine("Dados dois numeros recebidos por parametro 5 e 3: ");
            Console.WriteLine($"Resultado da multiplicação entre eles é {Resultado}!");
            Console.ReadKey();
        }
    }
}