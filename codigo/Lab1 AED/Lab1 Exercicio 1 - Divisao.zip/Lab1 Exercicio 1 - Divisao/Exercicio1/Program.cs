﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0;
            int num2 = 0; 
            int resultado = 0;

            for (int i = 1000; i <= 9999; i++)
            {
                num1 = i / 100;
                num2 = i % 100;
                resultado = (num1 + num2) * (num1 + num2);

                if (resultado == i)
                {
                    Console.WriteLine($" O Numero  {resultado}  atende aos requisitos do problema");
                }
            }
            Console.ReadKey();
        }
    }
}