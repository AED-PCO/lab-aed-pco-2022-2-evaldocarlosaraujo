﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 3;
            double y = 2;
            double Result = 0;
            
            Calculo(ref Result,x,y);
            Console.WriteLine($"O valor da operação de {x} elevado à {y} é: {Result} .");
            
            Console.ReadKey();
        }
        static void Calculo(ref double Result, double x, double y)
        {
            Result = Math.Pow(x, y);
        }

    }
}
