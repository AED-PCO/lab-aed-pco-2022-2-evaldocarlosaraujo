﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fatorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int Fat = 1;
            int n;

            Console.Write(" Calcular o fatorial do numero: ");

            n = int.Parse(Console.ReadLine());

            Fat = CalcFatorial(n);

            Console.WriteLine($" O Calculo Fatorial do Numero {n} é {Fat}.");

            Console.ReadKey();
        }

        static int CalcFatorial(int x)
        {
            int Fat;
            int i;

            for (i = 1, Fat = 1; i <= x; Fat = Fat * i++) ;

            return Fat;
        }
    }
}
