﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalculaNumeroPrimo
{
    class Program
    {
        static void Main(string[] args)
        {
            int Numero;
            int Divisores=0;
                
            Console.Write(" Entre com um numero: ");
            Numero = int.Parse(Console.ReadLine());

            for (int i = 1; i <= Numero; i++)
            {
                if (Numero % i == 0)
                    Divisores  ++;
            }
            if (Divisores == 2)
                Console.WriteLine($" O numero {Numero} é primo. ");
            else
                Console.WriteLine($" O numero {Numero} não é primo. ");
                Console.WriteLine();
                
            Console.WriteLine(" Programa para listar os números perfeitos de 1 a 1000.");

            for (int aux = 1; aux <= 1000; aux++)
            {
                ValidaNumeroPerfeito(aux);
            }
            static void ValidaNumeroPerfeito(int nummero)
            {
                List<int> divisores = new List<int>();
                int divisoresSoma = 0;

                for (int aux = 1; aux < nummero; aux++)
                {
                    if ((nummero % aux).Equals(0))
                    {
                        divisores.Add(aux);
                    }
                }
                divisores.ForEach(divisor =>
                {
                    divisoresSoma += divisor;
                });

                if (divisoresSoma.Equals(nummero))
                {
                    Console.WriteLine($" O número {nummero} é perfeito. ");
                    return;
                }
            }
                Console.ReadKey();
        }
    }
}