﻿/*Alguns números de quatro algarismos possuem uma característica particular. Se separamos esse número em dois grupos e os somarmos encontramos um outro número cujo quadrado é exatamente igual ao número fornecido anteriormente. Veja o exemplo:
 
Número = 3025

Separando o número em dois grupos de dois algarismos temos o 30 e o 25 . 
A soma de 30 com 25 é igual a 55
O Quadrado de 55 é igual a 3025.
 
Faça um programa que mostre os números de 1000 a 9999 que possuem essa característica.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0;
            int num2 = 0; 
            int resultado = 0;

            for (int i = 1000; i <= 9999; i++)
            {
                num1 = i / 100;
                num2 = i % 100;
                resultado = (num1 + num2) * (num1 + num2);

                if (resultado == i)
                {
                    Console.WriteLine($" O Numero  {resultado}  atende aos requisitos do problema");
                }
            }
        }
    }
}