﻿using System;

namespace Lab6_Exercicio3___SelectionSort
{
    class Program
    {

        public class InsertionSort
        {
            static void Main(string[] args)
            {
                int[] arr = new int[10] { 56, 1, 99, 67, 89, 23, 44, 12, 78, 34 };
                int n = 10;
                Console.WriteLine("Selection sort");
                Console.Write("Array Original: ");
                for (int i = 0; i < n; i++)
                {
                    Console.Write(arr[i] + " ");
                }
                int temp, Menor;
                for (int i = 0; i < n - 1; i++)
                {
                    Menor = i;
                    for (int j = i + 1; j < n; j++)
                    {
                        if (arr[j] < arr[Menor])
                        {
                            Menor = j;
                        }
                    }
                    temp = arr[Menor];
                    arr[Menor] = arr[i];
                    arr[i] = temp;
                }
                Console.WriteLine();
                Console.Write("Array ordenado: ");
                for (int i = 0; i < n; i++)
                {
                    Console.Write(arr[i] + " ");
                }
                Console.ReadKey();
            }
        }
    }
}

