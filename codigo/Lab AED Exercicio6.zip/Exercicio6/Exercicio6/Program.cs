﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 5;
            double y = 2;
            double Result = 0;
            
            Console.WriteLine("Entre com Valor de X: ");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Entre com Valor de y: ");
            y = double.Parse(Console.ReadLine());

            Calculo(ref x, ref y);

            Console.WriteLine($"O valor da operação de {x} elevado à {y} é: {Result} .");

            static void Calculo(double valor, ref double x, ref double y)
            {
                valor = Math.Pow(x, y);
            }
        }
    }
}
