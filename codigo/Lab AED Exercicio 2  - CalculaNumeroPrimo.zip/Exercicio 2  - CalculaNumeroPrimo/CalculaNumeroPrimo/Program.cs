﻿/*
Um Número é dito Primo se possui como divisores o número 1 e ele mesmo. Em outras palavras, um Número Primo possui dois divisores de 1 até ele.

Faça um programa que mostre se um determinado número inteiro, lido pelo teclado, é Primo.

Um Número é dito Perfeito se a soma de seus divisores menores que ele é igual a ele. Por exemplo, o número 6 possui os  divisores 1, 2 e 3, cuja soma é igual a 6.

Faça um programa que liste os números perfeitos de 1 a 1000.

*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalculaNumeroPrimo
{
    class Program
    {
        static void Main(string[] args)
        {
            int Numero;
            int Divisores=0;

                Console.Write("Entre com um numero: ");
                Numero = int.Parse(Console.ReadLine());
            for (int i = 1; i <= Numero; i++)
            {
                if (Numero % i == 0)
                    Divisores  ++;
            }
            if (Divisores == 2)
                Console.WriteLine($"O numero {Numero} é primo. ");
            else
                Console.WriteLine($"O numero {Numero} não é primo. ");


            Console.WriteLine(" Programa para listar os números perfeitos de 1 a 1000.");

            for (int aux = 1; aux <= 1000; aux++)
            {
                ValidaNumeroPerfeito(aux);
            }

            static void ValidaNumeroPerfeito(int userInput)
            {

                List<int> divisors = new List<int>();
                int divisorsSum = 0;

                for (int aux = 1; aux < userInput; aux++)
                {
                    if ((userInput % aux).Equals(0))
                    {
                        divisors.Add(aux);
                    }
                }

                divisors.ForEach(divisor =>
                {
                    divisorsSum += divisor;
                });

                if (divisorsSum.Equals(userInput))
                {
                    Console.WriteLine($" O número {userInput} é perfeito. ");
                    return;
                }

            }
                Console.ReadKey();
        }
    }
}