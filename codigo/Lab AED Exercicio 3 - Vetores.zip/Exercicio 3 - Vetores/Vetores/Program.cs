﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vetores
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrayR = new int[5];
            int[] arrayS = new int[5];

            ArrayInicial(arrayR);
            ArrayInicial(arrayS);

            Console.WriteLine("Array A");
            ImprimeArray(arrayR);

            Console.WriteLine("Array B");
            ImprimeArray(arrayS);

            int[] joinArray = ArrayJuncao(arrayR, arrayS);

            Console.WriteLine("Array C de Numeros Comuns entre A e B. ");
            ImprimeArray(joinArray);
        }

        static void ArrayInicial(int[] ArrayFinal)
        {
            for (int aux = 0; aux < 5; aux++)
            {
                ArrayFinal[aux] = new Random().Next(0, 10);
            }
        }

        static void ImprimeArray(int[] ArrayFinal)
        {
            for (int aux = 0; aux < ArrayFinal.Length; aux++)
            {
                Console.WriteLine(ArrayFinal[aux]);
            }
        }

        static int[] ArrayJuncao(int[] arrayA, int[] arrayB)
        {
            List<int> ArrayFinal = new List<int>();

            for (int aux1 = 0; aux1 < arrayA.Length; aux1++)
            {

                bool Comum = false;

                for (int aux2 = 0; aux2 < arrayB.Length; aux2++)
                {
                    if (arrayA[aux1].Equals(arrayB[aux2]))
                    {
                        Comum = true;
                    }
                }

                if (Comum)
                {
                    bool EstaDuplicado = false;
                    ArrayFinal.ForEach(x =>
                    {
                        if (x.Equals(arrayA[aux1]))
                        {
                            EstaDuplicado = true;
                        }
                    });

                    if (!EstaDuplicado)
                    {
                        ArrayFinal.Add(arrayA[aux1]);
                    }
                }
            }

            return ArrayFinal.ToArray();
        }
    }
}